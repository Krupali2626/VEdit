import React from 'react'

export default function RatioComponent() {
  return (
    <div>RatioComponent</div>
  )
}
