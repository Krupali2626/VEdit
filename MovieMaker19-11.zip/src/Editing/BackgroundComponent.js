import React from 'react'

export default function BackgroundComponent() {
  return (
    <div>BackgroundComponent</div>
  )
}
