import React from 'react'

export default function MusicComponent() {
  return (
    <div>MusicComponent</div>
  )
}
