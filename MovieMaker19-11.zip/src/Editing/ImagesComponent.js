import React from 'react'

export default function ImagesComponent() {
  return (
    <div>ImagesComponent</div>
  )
}
