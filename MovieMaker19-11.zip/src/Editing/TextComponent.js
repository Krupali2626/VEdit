import React from 'react'

export default function TextComponent() {
  return (
    <div>TextComponent</div>
  )
}
