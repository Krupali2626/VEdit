import React from 'react'

export default function AnimationComponent() {
  return (
    <div>AnimationComponent</div>
  )
}
