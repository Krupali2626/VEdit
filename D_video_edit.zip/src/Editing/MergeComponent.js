import React from 'react'

export default function MergeComponent() {
  return (
    <div>MergeComponent</div>
  )
}
