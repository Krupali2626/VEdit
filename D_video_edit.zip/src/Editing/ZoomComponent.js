import React from 'react'

export default function ZoomComponent() {
  return (
    <div>ZoomComponent</div>
  )
}
