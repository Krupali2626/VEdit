import React from 'react'

export default function ElementComponent() {
  return (
    <div>ElementComponent</div>
  )
}
